package com.util;

public class TemperatureOutsideRangeException extends Exception{

	public TemperatureOutsideRangeException(String str) {
	
		super(str);
	}
}
